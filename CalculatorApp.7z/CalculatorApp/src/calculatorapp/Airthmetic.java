/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package calculatorapp;

/**
 *
 * @author DSL6
 */
public class Airthmetic {
    public int  sum(int a,int b){System.out.println("a="+a +"b="+b);return a+b;}
    
}
