/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package calculatorapp;
import java.util.Arrays;
import java.util.Collections;
import java.util.*;
/**
 *
 * @author DSL6
 */
public class Ascending {
    public static ArrayList<Integer> Descending(ArrayList<Integer> arr){
//        int n=arr.length;
//        for(int i=0;i<n-1;i++){
//        for(int j=0;j<n-i-1;j++){
//            if(arr[j] > arr[j+1]){
//                int temp = arr[j];
//                arr[j]=arr[j+1];
//                arr[j+1]=temp;
//            }
//        }
//    }
        arr.sort(Collections.reverseOrder());
        
        return arr;
    }
     public static int[] Ascending(int arr[]){
        Arrays.sort(arr);
        return arr;
    }
}
