/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package calculatorapp;

/**
 *
 * @author DSL6
 */
public class Sorting {
     static void BUBBLESORT(int arr[],int n)
    {
        n=arr.length;
        int i,j,temp=0;
        for(i=0;i<n;i++)
        {
            for(j=0;j<n-i;j++)   
            {
                if(arr[j-1]>arr[j])
                {
                 temp=i;
                 i=j;
                 j=temp;
           } 
        }
    }
  }
}