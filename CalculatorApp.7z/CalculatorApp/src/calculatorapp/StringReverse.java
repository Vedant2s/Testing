/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package calculatorapp;

/**
 *
 * @author DSL6
 */
import java.io.*;
import java.util.Scanner;
public class StringReverse {
     public static void main (String[] args) {}
	public static String reverse(String str){
		String  nstr="";
		char ch;
	
	System.out.print("Original word: ");
	System.out.println(str); //Example word
	
	for (int i=0; i<str.length(); i++)
	{
		ch= str.charAt(i); //extracts each character
		nstr= ch+nstr; //adds each character in front of the existing string
	}
	System.out.println("Reversed word: "+ nstr);
        return nstr;
	}



}


    

