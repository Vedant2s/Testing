import calculatorapp.Airthmetic;
//import calculatorapp.Arithmatic;
import java.util.Arrays;
import java.util.Collection;
import static org.junit.Assert.*;import  org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
/**
 *
 * @author Admin
 */@RunWith(Parameterized.class)
public class AirthmeticTest {
    private int fno;private int sno;private int expresult;private Airthmetic airthmetic;
    public AirthmeticTest(int fno,int sno,int expresult) {super();this.fno=fno;this.sno=sno;this.expresult=expresult;
    }
   
    @BeforeClass
    public static void setUpClass() {
    }
   
//    @AfterClass
//    public static void tearDownClass() {
//    }
   
    @Before
    public void setUp() {airthmetic =new Airthmetic();
    }
   
   
@Parameterized.Parameters
public static Collection input(){ return Arrays.asList(new Object[][]{{-1,-2,-3},{11,22,33}});}
    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
 
@Test
public void testArithmetic(){ assertEquals (expresult,airthmetic.sum(fno,sno));}}














