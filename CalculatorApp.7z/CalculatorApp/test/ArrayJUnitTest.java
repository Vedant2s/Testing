/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import calculatorapp.CalculatorApp;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author DSL6
 */
public class ArrayJUnitTest {
    
    public ArrayJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("BEfore Class");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("After Class");
    }
    
    @Before
    public void setUp() {
        System.out.println("Before");
    }
    
    @After
    public void tearDown() {
        System.out.println("AFter");
    }
    @Test
    public void testFindMax(){
        assertEquals(45, CalculatorApp.findMax(new int[]{10, 30, 45, 21}));
        assertEquals(-1, CalculatorApp.findMax(new int[]{-12, -1, -3, -4, -2}));
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
