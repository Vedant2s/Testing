/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import calculatorapp.Ascending;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;

/**
 *
 * @author DSL6
 */
public class AscendingJUnit {
    
    public AscendingJUnit() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("BEfore Class");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("After Class");
    }
    
    @Before
    public void setUp() {
        System.out.println("Before");
    }
    
    @After
    public void tearDown() {
        System.out.println("AFter");
    }
    @Test
    public void testDescending(){
        ArrayList<Integer> testarr = new ArrayList<Integer>(Arrays.asList(7, 10, 8, 9, 6));
        ArrayList<Integer> resultarr = new ArrayList<Integer>(Arrays.asList(10, 9, 8, 7, 6));
        
        assertArrayEquals(resultarr.toArray(), Ascending.Descending(testarr).toArray());
    }
    
    @Test
    public void testAscending(){
        int [] testarr = {3,-1,-8,2,9};
        int [] resultarr = {-8, -1, 2, 3,9};
        assertArrayEquals(resultarr, Ascending.Ascending(testarr));
    }
    
}
