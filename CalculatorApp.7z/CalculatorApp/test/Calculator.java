/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import calculatorapp.CalculatorApp;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author DSL6
 */
public class Calculator {
    int a,b;
    double c;
    public Calculator() {
        
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("BEfore Class");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("After Class");
    }
    
    @Before
    public void setUp() {
        
        System.out.println("Before");
        a = 3; b = 8; 
        c = 2.5;
    }
    
    @After
    public void tearDown() {
        System.out.println("AFter");
    }
    
    @Test
    public void testadd(){
        assertEquals(11, CalculatorApp.add(a,b));
    }
    @Test
    public void testmul(){
        assertEquals(24, CalculatorApp.mul(a,b));
    }
    @Test
    public void testcube(){
        assertEquals(15.625, CalculatorApp.cube(c), 0.001);
    }
    

    
    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
